package com.amar.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/**
 * Simple 1-screen setup: automatically requests all required permissions
 * on first launch so no Termux/ADB commands are needed.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
        val title = TextView(this).apply {
            text = "அமர் (Amar) — Moto G35 5G Setup"
            textSize = 20f
        }
        val btnPerm = Button(this).apply {
            text = "1. Grant Mic & Notification Access"
            setOnClickListener { requestCorePermissions() }
        }
        val btnOverlay = Button(this).apply {
            text = "2. Allow Tiny Edge Dot (Non-blocking)"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        }
        val btnAcc = Button(this).apply {
            text = "3. Enable Amar App Control (Accessibility)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val btnStart = Button(this).apply {
            text = "4. Start Amar (Always Ready)"
            setOnClickListener {
                val svc = Intent(this@MainActivity, AmarForegroundService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc) else startService(svc)
                moveTaskToBack(true) // Minimizes immediately so your screen stays clean
            }
        }

        listOf(title, btnPerm, btnOverlay, btnAcc, btnStart).forEach { layout.addView(it) }
        setContentView(layout)
        requestCorePermissions()
    }

    private fun requestCorePermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }
}
