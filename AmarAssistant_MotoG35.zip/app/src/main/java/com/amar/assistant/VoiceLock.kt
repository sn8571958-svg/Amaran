package com.amar.assistant

import android.content.Context
import kotlin.math.*

/**
 * Pure-Kotlin Goertzel spectral voiceprint lock so ONLY the owner's voice
 * can trigger Amar commands — plus a secret override code ("I'm SN best mode")
 * when the owner's voice changes (cold, hoarse, or noisy environment).
 */
class VoiceLock(private val context: Context) {
    private val prefs = context.getSharedPreferences("amar_voice_prefs", Context.MODE_PRIVATE)
    private val bands = intArrayOf(90, 120, 150, 190, 240, 300, 380, 480, 600, 760, 960, 1220, 1550, 1960, 2500, 3200)

    private var overrideUntilMs: Long = 0L

    private val overridePhrases = listOf(
        "i'm sn best mode",
        "i am sn best mode",
        "sn best mode",
        "i'm sn_bist mode",
        "i am sn_bist mode",
        "sn_bist mode",
        "sn bist mode"
    )

    fun isOverrideActive(): Boolean = System.currentTimeMillis() < overrideUntilMs

    fun checkSecretOverride(spokenText: String): Boolean {
        val norm = spokenText.lowercase().trim()
        if (overridePhrases.any { norm.contains(it) }) {
            // Unlock for 15 minutes when secret code is spoken
            overrideUntilMs = System.currentTimeMillis() + 15 * 60 * 1000L
            return true
        }
        return false
    }

    fun clearOverride() {
        overrideUntilMs = 0L
    }

    fun isEnrolled(): Boolean = prefs.contains("owner_vector")

    fun enroll(pcmSamples: ShortArray, sampleRate: Int = 16000) {
        val vec = extractFeatures(pcmSamples, sampleRate)
        prefs.edit().putString("owner_vector", vec.joinToString(",")).apply()
    }

    fun verify(pcmSamples: ShortArray, sampleRate: Int = 16000, threshold: Double = 0.88): Boolean {
        if (isOverrideActive()) return true
        val saved = prefs.getString("owner_vector", null) ?: return true
        val ownerVec = saved.split(",").map { it.toDouble() }.toDoubleArray()
        val candidate = extractFeatures(pcmSamples, sampleRate)
        return cosineSimilarity(ownerVec, candidate) >= threshold
    }

    private fun extractFeatures(samples: ShortArray, sampleRate: Int): DoubleArray {
        val maxAmp = samples.maxOfOrNull { abs(it.toInt()) }?.coerceAtLeast(1) ?: 1
        val norm = DoubleArray(samples.size) { samples[it] / maxAmp.toDouble() }
        val frameLen = (sampleRate * 0.025).toInt().coerceAtLeast(64)
        val features = DoubleArray(bands.size)
        var frameCount = 0
        var start = 0
        while (start + frameLen <= norm.size) {
            for (b in bands.indices) {
                features[b] += goertzel(norm, start, frameLen, sampleRate, bands[b].toDouble())
            }
            frameCount++
            start += frameLen
        }
        val denom = frameCount.coerceAtLeast(1).toDouble()
        for (i in features.indices) features[i] = ln(1.0 + features[i] / denom)
        val l2 = sqrt(features.sumOf { it * it }).coerceAtLeast(1e-9)
        for (i in features.indices) features[i] /= l2
        return features
    }

    private fun goertzel(s: DoubleArray, offset: Int, len: Int, sr: Int, freq: Double): Double {
        val omega = 2.0 * PI * freq / sr
        val coeff = 2.0 * cos(omega)
        var q0: Double; var q1 = 0.0; var q2 = 0.0
        for (i in offset until offset + len) {
            q0 = coeff * q1 - q2 + s[i]
            q2 = q1; q1 = q0
        }
        return max(0.0, q1 * q1 + q2 * q2 - q1 * q2 * coeff) / len
    }

    private fun cosineSimilarity(a: DoubleArray, b: DoubleArray): Double {
        var dot = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]
        }
        return dot / (sqrt(na) * sqrt(nb)).coerceAtLeast(1e-9)
    }
}
