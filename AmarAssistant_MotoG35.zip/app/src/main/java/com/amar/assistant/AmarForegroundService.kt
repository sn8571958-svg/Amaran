package com.amar.assistant

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.util.Locale

/**
 * Always-on background service with a tiny non-blocking edge dot (12dp)
 * on the side of your Moto G35 5G screen.
 * Wakes on "Amar" / "அமர்", and unlocks via "I'm SN best mode" if your voice changes.
 */
class AmarForegroundService : Service(), TextToSpeech.OnInitListener {

    private var edgeDot: View? = null
    private var windowManager: WindowManager? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var voiceLock: VoiceLock

    override fun onCreate() {
        super.onCreate()
        voiceLock = VoiceLock(this)
        startAsForeground()
        showTinyEdgeIndicator()
        tts = TextToSpeech(this, this)
        startWakeWordListener()
    }

    private fun startAsForeground() {
        val channelId = "amar_active_channel"
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mgr.createNotificationChannel(
                NotificationChannel(channelId, "Amar Assistant", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notif = Notification.Builder(this, channelId)
            .setContentTitle("Amar is ready")
            .setContentText("Say 'Amar' anytime. Say 'I'm SN best mode' if your voice changes.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(101, notif)
    }

    private fun showTinyEdgeIndicator() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val sizePx = (12 * resources.displayMetrics.density).toInt()
        edgeDot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(180, 0, 200, 255))
            }
        }
        val params = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 8
        }
        windowManager?.addView(edgeDot, params)
    }

    private fun startWakeWordListener() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    when {
                        voiceLock.checkSecretOverride(heard) -> {
                            speak("SN Best Mode activated. Listening to you now.")
                        }
                        heard.contains("lock voice", ignoreCase = true) -> {
                            voiceLock.clearOverride()
                            speak("Strict voice lock restored.")
                        }
                        heard.contains("amar", ignoreCase = true) || heard.contains("அமர்") -> {
                            speak("Yes, I am listening.")
                            AmarAccessibilityService.instance?.executeCommandChain(heard)
                        }
                    }
                    restartListening()
                }
                override fun onError(error: Int) { restartListening() }
                override fun onReadyForSpeech(p0: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(p0: Float) {}
                override fun onBufferReceived(p0: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p0: Bundle?) {}
                override fun onEvent(p0: Int, p1: Bundle?) {}
            })
        }
        restartListening()
    }

    private fun restartListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
        }
        recognizer?.startListening(intent)
    }

    private fun speak(msg: String) {
        tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "amar_utterance")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ta", "IN")
    }

    override fun onDestroy() {
        edgeDot?.let { windowManager?.removeView(it) }
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
