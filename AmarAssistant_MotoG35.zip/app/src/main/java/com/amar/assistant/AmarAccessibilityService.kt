package com.amar.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Executes voice-ordered in-app actions (open any app, tap any button, type text,
 * scroll, go home/back) without root and without disturbing your screen.
 */
class AmarAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AmarAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Strictly passive: never acts on its own without an explicit user voice command.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun executeCommandChain(rawCommand: String) {
        val cleaned = rawCommand.trim()
            .removePrefix("Amar").removePrefix("amar")
            .removePrefix("அமர்").trim(' ', ',', ':')
        val steps = cleaned.split(Regex("\\s+(?:and|then|அப்புறம்)\\s+", RegexOption.IGNORE_CASE))
        for (step in steps) {
            runSingleStep(step.trim())
            Thread.sleep(600)
        }
    }

    private fun runSingleStep(step: String) {
        val lower = step.lowercase()
        when {
            lower.startsWith("open ") || step.contains("திற") -> {
                val appQuery = lower.removePrefix("open ").replace("திற", "").trim()
                launchAppByName(appQuery)
            }
            lower.startsWith("click ") || lower.startsWith("tap ") || step.contains("கிளிக்") -> {
                val target = lower.removePrefix("click ").removePrefix("tap ")
                    .replace("கிளிக்", "").replace("செய்", "").trim()
                clickNodeByText(target)
            }
            lower.startsWith("type ") -> {
                val text = step.substring(5).trim()
                typeIntoFocusedField(text)
            }
            lower.contains("home") || step.contains("ஹோம்") -> performGlobalAction(GLOBAL_ACTION_HOME)
            lower.contains("back") || step.contains("பின்னால்") -> performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun launchAppByName(appQuery: String) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val apps = pm.queryIntentActivities(intent, 0)
        val match = apps.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(appQuery)
        } ?: return
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
    }

    private fun clickNodeByText(label: String) {
        val root = rootInActiveWindow ?: return
        val matches = root.findAccessibilityNodeInfosByText(label)
        for (node in matches) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) {
                    current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return
                }
                current = current.parent
            }
        }
    }

    private fun typeIntoFocusedField(text: String) {
        val root = rootInActiveWindow ?: return
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
